//
//  Constant.swift
//  DemoPractice
//
//  Created by Nirav Joshi on 20/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import Foundation
import UIKit

class Constant : NSObject
{
    static let myname = "Hardik"
    
    struct testing {
        static let first = "Talaviya"
    }
}


class employee {
    class func first(firstname : String, lastname : String) -> String
    {
        return firstname + " " + lastname
    }
}

struct City
{
    var population : Int
    mutating func changePopulation(newpopulation : Int)
    {
        population = newpopulation //error: cannot modify property "popultion"
    }
}
