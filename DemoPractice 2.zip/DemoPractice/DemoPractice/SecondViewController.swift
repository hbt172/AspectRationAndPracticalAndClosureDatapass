//
//  SecondViewController.swift
//  DemoPractice
//
//  Created by Nirav Joshi on 20/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var ContainerView : UIView!
    @IBOutlet weak var SegmentCV: UICollectionView!
    
    var arryCollection : NSMutableArray = ["A","B","C","D","E"]
    var selectedIndex : Int =  0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(arryCollection)
        SegmentCV.reloadData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arryCollection.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SegmentCollectionCell", for: indexPath) as! SegmentCollectionCell
        
        cell.lblTitle.text = arryCollection[indexPath.row] as? String
        if selectedIndex == indexPath.row
        {
            cell.SeprateView.backgroundColor = UIColor.blue
        }
        else
        {
            cell.SeprateView.backgroundColor = UIColor.clear
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
        SegmentCV.scrollToItem(at: IndexPath.init(row: selectedIndex, section: 0), at: UICollectionViewScrollPosition.centeredHorizontally, animated: true)
        if selectedIndex == 2
        {
            ThirdVC.view.frame = ContainerView.bounds
            ContainerView.addSubview(ThirdVC.view)
        }
        SegmentCV.reloadData()
    }

    private lazy var ThirdVC : ThirdViewController = {
       let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let controller = storyboard.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        controller.nav = navigationController
        return controller
    }()
    
    
    
}
