//
//  SegmentCollectionCell.swift
//  DemoPractice
//
//  Created by Nirav Joshi on 20/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class SegmentCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var SeprateView: UIView!
}
