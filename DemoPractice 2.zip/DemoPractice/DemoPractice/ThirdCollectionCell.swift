//
//  ThirdCollectionCell.swift
//  DemoPractice
//
//  Created by Nirav Joshi on 20/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ThirdCollectionCell: UICollectionViewCell {
    
}
