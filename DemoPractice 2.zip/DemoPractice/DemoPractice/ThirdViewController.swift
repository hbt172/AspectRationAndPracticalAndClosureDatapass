//
//  ThirdViewController.swift
//  DemoPractice
//
//  Created by Nirav Joshi on 20/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
    @IBOutlet weak var CVDetails: UICollectionView!
    
    var nav : UINavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()
        CVDetails.reloadData()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! ThirdCollectionCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if (UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad) {
            // Ipad
            return CGSize(width: self.CVDetails.frame.size.width/2.1 , height: 430)
        } else {
            // Iphone
            return CGSize(width: self.CVDetails.frame.size.width/2.1 , height: 215)
        }
    }
}
