//
//  ViewController.swift
//  DemoPractice
//
//  Created by Nirav Joshi on 20/09/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import Localize_Swift
import Alamofire
import Alamofire_SwiftyJSON
import PhotosUI
enum Gender :String { // enum with type
    case male = "I am male"
    case female
}

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    @IBOutlet weak var imgViewGallery: UIImageView!
    var imagePicker = UIImagePickerController()
    var strString = "Hardik"
    @IBOutlet weak var lblTitle: UILabel!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
       
        
        imagePicker.delegate = self
        
        print(Gender.male) // prints “male”
        print(Gender.male.rawValue) // prints “I am male”
        print(Gender.male.hashValue) // prints 0
        print(Gender.female)
        print(Gender.female.rawValue)
        print(Gender.female.hashValue)
        
        print(Constant.myname)
        print(Constant.testing.first)
        print(employee.first(firstname: "Hardik", lastname: "Talaviya"))
        lblTitle.text = "Hello".localized()
        var objcity = City(population: 2000)
        objcity.changePopulation(newpopulation: 3000)
        print(objcity.population)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnEnglishClick(_ sender: Any) {
        Localize.setCurrentLanguage("en")
        lblTitle.text = "Hello".localized()
    }
    @IBAction func btnArabicClick(_ sender: Any) {
        Localize.setCurrentLanguage("ar")
        lblTitle.text = "Hello".localized()
    }
    
    @IBAction func btnSetAction(_ sender: Any) {
        let someIntSet:Set = [1, 2, 3, 4, 5, 6, 7, 8, 9,9]
        print(someIntSet.sorted(by: { (a, b) -> Bool in
            return a > b
        }))
        
        print(someIntSet.startIndex)
        
        // call variadic parameter function
        
        vari(members: 4,3,5)
        vari(members: 4.5, 3.1, 5.6)
        vari(members: "Swift 4", "Enumerations", "Closures")
        
    }
    
    // Variadic Parameters function
    func vari<N>(members: N...){
        for i in members {
            print(i)
        }
    }
    
    
    @IBAction func btnWSClick(_ sender: Any)
    {
        let header: HTTPHeaders = [
            
            "Authorization" : "Bearer eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImlkIjoiMDU5ZWFiMDMtZWU0OC00Yzg1LWE4ZTctMTY3YTAxMzIyMTFlIiwic29jaWFsX2lkIjoiMTA0MTkyMDg4NDY4Mjg0MjExM0B0d2l0dGVyIiwic29jaWFsX21lZGlhIjoidHdpdHRlciJ9LCJpYXQiOjE1MzczMzM4MjAsImF1ZCI6InVybjpmb28iLCJpc3MiOiJpQmxhemluZyJ9.Yzmr4GjsLSzwPNQEJaWy91iQsbVs6ToccD849XBzmlSI4Rbb5NuWHu76IVc-wTrdjD-07YSk4COEJj7_xngMMDInunbpsrXu176qjSsFI2C120p0EQDkymX2vMxU_Euoc3QoSHkP62yZErYgywaXWPknVT6bKKt1l5EKBtQMX2m8JQ1bX0fM6__dL5t5ue-AG6Ty3WUBuew5TxvldvRVhaGOKMq_nSqHCzWHJkJsJ6MUQ75VA_qRHg94lOHiwTxMlfJaWu8xiImaeQ7EBUY9tVvjzFjgYdzlcE1q7-N5gKWC1Y7b3t2oHdwlMmW2CLLCpw_RLPxZJPchRqeutny6wWWDvSS5zNonrILZKcbvOdFVAoe3aoMVRalhcdN1RuIpw8qwyIeRIIpodwQVN8MkvA0Gm3uaMlaTbTkI4BzrpIG1UaIR8lavbopY2CGLcQnWaI8Fjpclsrx7V9ZD0hj2JeMKCgMdx4o071ExEDj2eT-ogt9-FvRi17lqM4msSA44pShRfltckGtcPRvMXeWnH-ytSSGXctrvFZUyKj_tyHqBg0JnBgStpiIpr6Fc9ozbAoR56hXW7UfFf_3yY7ras595i-6IXRzsNRCYoWzDIJ-7DMHOPcf7-RLs5XZ2WcCezz63YBDRLWhYbFCwEKP1bRKLpP1pd7RonyoFuAEVvDo",
            "Content-Type" : "application/json"
        ]
        let apiName: String = "http://46.249.63.99:3000/api/v1/like/get-like-suggestions-if-no-new-users?offset=0&limit=50"
        Alamofire.request(apiName, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).responseSwiftyJSON { (response) in
            //            print(response.result.value as Any)
            if let data = response.result.value
            {
                if data["success"].boolValue == true
                {
                    //                    let resdata = data["data"].arrayValue
                    //                    print(resdata[0]["profile_images"][0])
                    let resdata = data["data"].arrayObject
                    print(((resdata![0] as! [String:Any])["profile_images"] as! [String])[0])
                    
                }
            }
        }
        
        
    }
   
    @IBAction func btnOpenGalleryClick(_ sender: UIButton) {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        /*If you want work actionsheet on ipad
         then you have to use popoverPresentationController to present the actionsheet,
         otherwise app will crash on iPad */
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            alert.popoverPresentationController?.sourceView = sender
            alert.popoverPresentationController?.sourceRect = sender.bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera()
    {
    if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imgViewGallery.image = pickedImage
        }
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
   
}

