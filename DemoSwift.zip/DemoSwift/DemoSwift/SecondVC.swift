//
//  SecondVC.swift
//  DemoSwift
//
//  Created by Hardik on 30/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {
var callback: ((String?,UIColor?)->())?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnBackClick(_ sender: Any) {
        callback?("first text",UIColor.green)
        self.navigationController?.popViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
