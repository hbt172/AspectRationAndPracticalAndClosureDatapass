//
//  ViewController.swift
//  DemoSwift
//
//  Created by Hardik on 30/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.performSegue(withIdentifier: "SecondVC", sender: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SecondVC"
        {
            let secondViewController = segue.destination as! SecondVC
            //secondViewController.delegate = self
            secondViewController.callback = { (text,color)  in
                print("\(text!)")
                self.view.backgroundColor = color
            }
        }
    }
}

